﻿using CoreAndFood.Data.Models;
using System.Collections.Generic;
using System.Linq;

namespace CoreAndFood.Repositories
{
    public class FoodRepository: GenericRepository<Food>
    {

    }
}
