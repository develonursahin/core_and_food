﻿namespace CoreAndFood.Data
{
    public class Class2
    {
        public string foodname { get; set; }
        public int stock { get; set;}
    }
}
