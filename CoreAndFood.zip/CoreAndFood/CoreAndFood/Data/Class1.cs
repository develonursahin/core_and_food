﻿namespace CoreAndFood.Data
{
    public class Class1
    {
        public string proname { get; set; }
        public int stock { get; set; }

    }
}
